package modelo;

public class Instrutor extends Funcionario{
	private String aula;
	
	public Instrutor(){
		super();
	}
}