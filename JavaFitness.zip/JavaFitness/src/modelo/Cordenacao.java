package modelo;

public class Cordenacao extends Funcionario{
	
	public Cordenacao(){
		super ();
	}

}